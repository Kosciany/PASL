Przgotuj Dockerfile, zbuduj obraz i uruchom kontener korzystający z Python 3.9, zawierający pliki:
* obliczenia.py
* requirements.txt

1. Skopiuj Dockerfile z przykladowej_apki do folderu kontenery
2. Zmodyfikuj dockerfile
    * zweryfikuj jakie pliki są faktycznie potrzebne w kontenerze
    * usuń EXPOSE, apka nie jest sieciowa
    * zmień sposób wywołania skryptu pythonowego (sprawdź prezentację)