Przgotuj Dockerfile, zbuduj obraz i uruchom kontener korzystający z Python 3.9, zawierający pliki:
* obliczenia.py
* requirements.txt