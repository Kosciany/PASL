import base64
from fastapi import FastAPI
from fastapi.responses import HTMLResponse



with open("Docker.jpg", "rb") as image_file:
    encoded_img = base64.b64encode(image_file.read()).decode()
app = FastAPI()

html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Hello from Container</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        .spinner {{
            animation: spin 10s linear infinite;
        }}

        @keyframes spin {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}
    </style>
</head>
<body>
    <div class="container text-center">
        <h1 class="mb-5 pb-5"->Hello from Container</h1>
        <img class="spinner" src="data:image/jpeg;base64,{encoded_img}" style="height: 200px; width:auto;"/>
"""

@app.get("/", response_class=HTMLResponse)
async def read_item():

    return HTMLResponse(content=html_content, status_code=200)

