
# Aplikacja sieciowa w Docker

Wejdź do katalogu aplikacji i zbuduj kontener:
```bash
sudo docker build -t my-fastapi-app .
```

W jednym z okien terminala sprawdź działanie aplikacji
```bash
sudo docker run -p 8000:8000 my-fastapi-app
```

Spróbuj wywołać aplikację na innym porcie
```bash
sudo docker run -p 9000:8000 my-fastapi-app
```