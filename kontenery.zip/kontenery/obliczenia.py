# %%
import numpy as np

random_ints = np.random.randint(0, high=101, size=100, dtype=int)

counts = np.bincount(random_ints)



bin_counts = np.zeros(10, dtype=int)
for i in range(10):
    bin_counts[i] = np.sum(counts[i*10:(i+1)*10])



for i in range(10):
    print(f'{i*10:2d} - {(i+1)*10:3d} :', bin_counts[i]*'#')
# %%
